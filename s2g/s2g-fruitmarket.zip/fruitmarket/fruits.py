fruits = [
        {'name': 'apple',     'price': 14.3},
        {'name': 'banana',    'price': 15.7},
        {'name': 'cherry',    'price': 17.9},
        {'name': 'grape',     'price': 23.9},
        {'name': 'mango',     'price': 25.2},
        {'name': 'orange',    'price': 12.4},
        {'name': 'papaya',    'price': 87.9},
        {'name': 'pineapple', 'price': 23.2}
]

fruits = { i: v for i, v in enumerate(fruits) }
