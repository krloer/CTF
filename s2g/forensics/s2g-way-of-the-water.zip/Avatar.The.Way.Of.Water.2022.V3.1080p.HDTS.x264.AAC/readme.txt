Genre: Science Fiction, Action, Adventure
Director: James Cameron
Stars: Sam Worthington, Zoe Saldaña, Sigourney Weaver, Stephen Lang, Kate Winslet
Plot: Set more than a decade after the events of the first film, learn the story of the Sully family (Jake, Neytiri, and their kids), the trouble that follows them, the lengths they go to keep each other safe, the battles they fight to stay alive, and the tragedies they endure.
Language: English
Subtitles: English [Hardcoded]
Source: Avatar.The.Way.Of.Water.2022.V3.1080p.HDTS.x264.AAC
 
https://www.imdb.com/title/tt1630029

VIDEO FIX:
If video doesn't play please run "blackscreen_fix.bat" file found at the "./video_fix" folder