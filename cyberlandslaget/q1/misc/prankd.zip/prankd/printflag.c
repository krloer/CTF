#include <stdio.h>
#include "ignore_this_file.h"

int main()
{
    char ＊ decrypted_flag = decrypt_flag()；
    ｐｕｔｓ(decrypted_flag)；
}