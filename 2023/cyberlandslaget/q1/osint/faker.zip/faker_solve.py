import csv

def valid_credit_card_number(credit_card_number):
    # TODO write your code here
    return False

def valid_kid_number(kid_number):
    # TODO write your code here
    return False

with open("faker_data.txt") as csvfile:
    reader = csv.DictReader(csvfile)

    for row in reader:
        # The credit card number as an integer
        credit_card_number = int(row["ccNo"])
        
        # The KID number for the last bill paid
        bill_kid = int(row["lastBillKID"])
        
        # If both of these are valid, we're good!
        if valid_credit_card_number(credit_card_number) and valid_kid_number(bill_kid):
           print(f"The hacker must be {row['firstName']} {row['lastName']}!")
           print(f"The flag is flag{{{row['userid']}}}")