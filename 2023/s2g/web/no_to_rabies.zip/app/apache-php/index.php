<?php
    echo "Not much to see here :)";
?>